/**
 * Hybrid Trajectory Service: Stabilized & Visually Corrected
 * 1) Physics: Z-Up World (Internal)
 * 2) Visuals: Y-Up World (External/UI) via rotation fix
 * 3) Stationary: windowed stats + hysteresis
 * 4) Drift control: pitch/roll re-align (preserve yaw) + 3-state Kalman (p,v,b)
 */

import { IMUSample } from '../ble/constants';
import { Vec3, Vec3Math } from './Vec3';
import { Quaternion, QuatMath } from './QuaternionMath';

export interface TrajectoryPoint {
    timestamp: number;
    position: Vec3;
    rotation: Quaternion;
    relativePosition: Vec3;
}

// --- Kalman Filter 1D (3-State: Pos, Vel, Bias) ---
class KalmanFilter1D {
    // State x = [p, v, b]
    private x: number[] = [0, 0, 0];
    private P: number[][] = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
    ];

    // Process Noise Q (tune if needed)
    private Q: number[][] = [
        [1e-5, 0, 0], // pos
        [0, 1e-4, 0], // vel
        [0, 0, 1e-6], // bias random walk
    ];

    // Measurement Noise
    private R_v: number = 0.001; // ZUPT velocity
    private R_b: number = 0.01;  // bias observation from acc_linear during stationary

    reset() {
        this.x = [0, 0, 0];
        this.P = [
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 0.1],
        ];
    }

    predict(acc_in: number, dt: number) {
        if (dt <= 0) return;

        const [p, v, b] = this.x;

        const acc_eff = acc_in - b;
        this.x[0] = p + v * dt + 0.5 * acc_eff * dt * dt;
        this.x[1] = v + acc_eff * dt;
        this.x[2] = b;

        // F = [[1, dt, -0.5*dt^2], [0, 1, -dt], [0, 0, 1]]
        const F = [
            [1, dt, -0.5 * dt * dt],
            [0, 1, -dt],
            [0, 0, 1],
        ];

        const P = this.P;
        const FP = Array(3).fill(0).map(() => Array(3).fill(0));

        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                FP[i][j] = F[i][0] * P[0][j] + F[i][1] * P[1][j] + F[i][2] * P[2][j];
            }
        }

        const P_next = Array(3).fill(0).map(() => Array(3).fill(0));
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                const val = FP[i][0] * F[j][0] + FP[i][1] * F[j][1] + FP[i][2] * F[j][2];
                P_next[i][j] = val + this.Q[i][j];
            }
        }
        this.P = P_next;
    }

    updateZUPT(acc_linear_in: number) {
        // 1) Observe v = 0
        this.scalarUpdate(1, 0, this.R_v);

        // 2) Observe bias ~= acc_linear_in (because true linear acc ~= 0 at rest)
        this.scalarUpdate(2, acc_linear_in, this.R_b);
    }

    private scalarUpdate(stateIdx: number, measurement: number, noiseR: number) {
        const y = measurement - this.x[stateIdx];
        const S = this.P[stateIdx][stateIdx] + noiseR;

        const K = [
            this.P[0][stateIdx] / S,
            this.P[1][stateIdx] / S,
            this.P[2][stateIdx] / S,
        ];

        this.x[0] += K[0] * y;
        this.x[1] += K[1] * y;
        this.x[2] += K[2] * y;

        const P_new = Array(3).fill(0).map(() => Array(3).fill(0));
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                P_new[i][j] = this.P[i][j] - K[i] * this.P[stateIdx][j];
            }
        }
        this.P = P_new;
    }

    getPosition() { return this.x[0]; }
    getVelocity() { return this.x[1]; }
    getBias() { return this.x[2]; }
}

// --- Madgwick (Orientation) ---
class Madgwick {
    public q: Quaternion = { w: 1, x: 0, y: 0, z: 0 };
    private beta: number;

    constructor(beta: number = 0.033) {
        this.beta = beta;
    }

    public setQuaternion(q: Quaternion) {
        this.q = { ...q };
    }

    public update(gx: number, gy: number, gz: number, ax: number, ay: number, az: number, dt: number) {
        let q1 = this.q.w, q2 = this.q.x, q3 = this.q.y, q4 = this.q.z;
        const normRecip = (n: number) => (n === 0 ? 0 : 1 / Math.sqrt(n));

        let qDot1 = 0.5 * (-q2 * gx - q3 * gy - q4 * gz);
        let qDot2 = 0.5 * (q1 * gx + q3 * gz - q4 * gy);
        let qDot3 = 0.5 * (q1 * gy - q2 * gz + q4 * gx);
        let qDot4 = 0.5 * (q1 * gz + q2 * gy - q3 * gx);

        if (!((ax === 0.0) && (ay === 0.0) && (az === 0.0))) {
            let recipNorm = normRecip(ax * ax + ay * ay + az * az);
            ax *= recipNorm; ay *= recipNorm; az *= recipNorm;

            const _2q1 = 2.0 * q1;
            const _2q2 = 2.0 * q2;
            const _2q3 = 2.0 * q3;
            const _2q4 = 2.0 * q4;
            const _4q1 = 4.0 * q1;
            const _4q2 = 4.0 * q2;
            const _4q3 = 4.0 * q3;
            const _8q2 = 8.0 * q2;
            const _8q3 = 8.0 * q3;
            const q1q1 = q1 * q1;
            const q2q2 = q2 * q2;
            const q3q3 = q3 * q3;
            const q4q4 = q4 * q4;

            let s1 = _4q1 * q3q3 + _2q3 * ax + _4q1 * q2q2 - _2q2 * ay;
            let s2 = _4q2 * q4q4 - _2q4 * ax + 4.0 * q1q1 * q2 - _2q1 * ay - _4q2 + _8q2 * q2q2 + _8q2 * q3q3 + _4q2 * az;
            let s3 = 4.0 * q1q1 * q3 + _2q1 * ax + _4q3 * q4q4 - _2q4 * ay - _4q3 + _8q3 * q2q2 + _8q3 * q3q3 + _4q3 * az;
            let s4 = 4.0 * q2q2 * q4 - _2q2 * ax + 4.0 * q3q3 * q4 - _2q3 * ay;

            recipNorm = normRecip(s1 * s1 + s2 * s2 + s3 * s3 + s4 * s4);
            s1 *= recipNorm; s2 *= recipNorm; s3 *= recipNorm; s4 *= recipNorm;

            qDot1 -= this.beta * s1;
            qDot2 -= this.beta * s2;
            qDot3 -= this.beta * s3;
            qDot4 -= this.beta * s4;
        }

        q1 += qDot1 * dt;
        q2 += qDot2 * dt;
        q3 += qDot3 * dt;
        q4 += qDot4 * dt;

        const recipNorm = normRecip(q1 * q1 + q2 * q2 + q3 * q3 + q4 * q4);
        this.q.w = q1 * recipNorm;
        this.q.x = q2 * recipNorm;
        this.q.y = q3 * recipNorm;
        this.q.z = q4 * recipNorm;
    }
}

export class TrajectoryService {
    private p: Vec3 = { x: 0, y: 0, z: 0 };
    private v: Vec3 = { x: 0, y: 0, z: 0 };
    private q: Quaternion = { w: 1, x: 0, y: 0, z: 0 };

    private kX = new KalmanFilter1D();
    private kY = new KalmanFilter1D();
    private kZ = new KalmanFilter1D();
    private madgwick: Madgwick = new Madgwick(0.015);

    private readonly GRAVITY = 9.81;

    // If your real rate is 1000 Hz, set expectedHz=1000 or adjust bufferSize.
    private expectedHz = 100;
    private bufferSize = 50; // computed from expectedHz

    private stationaryTick = 0;
    private movingTick = 0;
    private isStatState = false;

    private accelBuffer: number[] = [];
    private gyroBuffer: number[] = [];

    private rawDataBuffer: Array<any> = [];

    private isCalibrating = false;
    private calibrationBuffer: IMUSample[] = [];

    private lastTimestamp = 0;
    private isOrientationInitialized = false;

    private initialQ: Quaternion = { w: 1, x: 0, y: 0, z: 0 };
    private baselineP: Vec3 = { x: 0, y: 0, z: 0 };

    // STARTUP BUFFER (for robust gravity alignment)
    private startupBuffer: { ax: number, ay: number, az: number }[] = [];
    private readonly STARTUP_SAMPLES = 20; // ~0.2s at 100Hz

    private realtimeEnabled = false;
    private path: TrajectoryPoint[] = [];

    // CRITICAL: keep lastPoint even in record-only
    private lastPoint: TrajectoryPoint | null = null;

    constructor(expectedHz: number = 100) {
        this.setExpectedHz(expectedHz);
        this.reset();
    }

    public setExpectedHz(hz: number) {
        this.expectedHz = Math.max(10, hz);
        // 250 ms window by default
        this.bufferSize = Math.max(10, Math.round(this.expectedHz * 0.25));
    }

    reset() {
        console.log('[Hybrid] Full Reset...');
        this.p = Vec3Math.zero();
        this.v = Vec3Math.zero();
        this.q = QuatMath.identity();

        this.madgwick = new Madgwick(0.015);
        this.kX.reset(); this.kY.reset(); this.kZ.reset();

        this.isOrientationInitialized = false;
        this.lastTimestamp = 0;

        this.path = [];
        this.lastPoint = null;

        this.accelBuffer = [];
        this.gyroBuffer = [];
        this.rawDataBuffer = [];
        this.baselineP = Vec3Math.zero();

        this.stationaryTick = 0;
        this.movingTick = 0;
        this.isStatState = false;

        this.startupBuffer = [];
    }

    resetKinematics() {
        this.p = Vec3Math.zero();
        this.v = Vec3Math.zero();

        this.path = [];
        this.lastPoint = null;

        this.accelBuffer = [];
        this.gyroBuffer = [];
        this.rawDataBuffer = [];

        this.baselineP = Vec3Math.zero();

        // CRITICAL
        this.kX.reset();
        this.kY.reset();
        this.kZ.reset();

        console.log('[Hybrid] Kinematics Reset');
    }

    processSample(sample: IMUSample): TrajectoryPoint {
        const t = sample.timestampMs;

        if (this.isCalibrating) {
            this.calibrationBuffer.push(sample);
            const out = { timestamp: t, position: Vec3Math.zero(), rotation: { ...this.q }, relativePosition: Vec3Math.zero() };
            this.lastPoint = out;
            return out;
        }

        // scale to m/s^2 and rad/s
        const a_meas: Vec3 = { x: sample.ax * this.GRAVITY, y: sample.ay * this.GRAVITY, z: sample.az * this.GRAVITY };
        const w_meas: Vec3 = { x: sample.gx * (Math.PI / 180), y: sample.gy * (Math.PI / 180), z: sample.gz * (Math.PI / 180) };

        // HOT START: Buffer N samples to average gravity
        if (!this.isOrientationInitialized) {
            this.lastTimestamp = t; // keep updating timestamp so first dt is small/valid

            // Accumulate raw g-force
            this.startupBuffer.push({ ax: a_meas.x, ay: a_meas.y, az: a_meas.z });

            if (this.startupBuffer.length < this.STARTUP_SAMPLES) {
                // Still collecting... return zero-point
                const out = { timestamp: t, position: Vec3Math.zero(), rotation: { ...this.initialQ }, relativePosition: Vec3Math.zero() };
                this.lastPoint = out;
                return out;
            }

            // Computed average gravity vector
            const meanAx = this.startupBuffer.reduce((s, v) => s + v.ax, 0) / this.STARTUP_SAMPLES;
            const meanAy = this.startupBuffer.reduce((s, v) => s + v.ay, 0) / this.STARTUP_SAMPLES;
            const meanAz = this.startupBuffer.reduce((s, v) => s + v.az, 0) / this.STARTUP_SAMPLES;

            const qInit = this.getRotationFromGravity(meanAx, meanAy, meanAz);
            this.q = qInit;
            this.madgwick.setQuaternion(qInit);
            this.initialQ = qInit;

            this.isOrientationInitialized = true;
            this.startupBuffer = []; // clear to save memory

            const out = { timestamp: t, position: Vec3Math.zero(), rotation: { ...this.q }, relativePosition: Vec3Math.zero() };
            this.lastPoint = out;
            console.log(`[Hybrid] Hot Start Executed (Avg of ${this.STARTUP_SAMPLES} samples). Init Gravity: [${meanAx.toFixed(2)}, ${meanAy.toFixed(2)}, ${meanAz.toFixed(2)}]`);
            return out;
        }

        // DT control
        let dt = (t - this.lastTimestamp) / 1000.0;
        this.lastTimestamp = t;

        // 1) invalid dt
        if (dt <= 0) return this.getLastPoint(t);

        // 2) HOLD for suspicious short gap
        if (dt > 0.05 && dt <= 0.2) {
            return this.getLastPoint(t);
        }

        // 3) RESET for large gap
        if (dt > 0.2) {
            console.warn(`[Hybrid] Large Gap detected (${dt.toFixed(3)}s). Resetting Kinematics.`);
            this.resetKinematics();
            this.isOrientationInitialized = false; // force gravity re-align next sample
            const out = { timestamp: t, position: Vec3Math.zero(), rotation: { ...this.q }, relativePosition: Vec3Math.zero() };
            this.lastPoint = out;
            return out;
        }

        this.updateBuffers(a_meas, w_meas);

        // Stationary logic
        const { isCandidate, metrics } = this.checkStationaryCandidate();

        if (isCandidate) {
            this.stationaryTick += dt;
            this.movingTick = 0;
        } else {
            this.movingTick += dt;
            this.stationaryTick = 0;
        }

        // Hysteresis: enter after 300ms stable, exit after 100ms moving
        if (!this.isStatState && this.stationaryTick > 0.3) {
            this.isStatState = true;
            // console.log('[Hybrid] Entered Stationary', metrics);
        } else if (this.isStatState && this.movingTick > 0.1) {
            this.isStatState = false;
            // console.log('[Hybrid] Exited Stationary');
        }

        const isStat = this.isStatState;

        // RE-ALIGNMENT: if stationary long enough, re-lock pitch/roll to gravity but preserve yaw
        if (isStat && this.stationaryTick > 0.5) {
            const currentEuler = QuatMath.toEuler(this.q); // roll/pitch/yaw
            const yaw = currentEuler.z;

            const q_yaw = QuatMath.fromAxisAngle({ x: 0, y: 0, z: 1 }, yaw);
            const q_gravity = this.getRotationFromGravity(a_meas.x, a_meas.y, a_meas.z);

            // IMPORTANT:
            // This order can be flipped depending on your convention.
            // Start with the most likely for your codebase. If aWtest is not ~[0,0,9.81], flip it.
            let q_new = QuatMath.normalize(QuatMath.multiply(q_yaw, q_gravity));

            // Validate quickly (optional; remove if you want)
            // const Rtest = QuatMath.toRotationMatrix(q_new);
            // const aWtest = Rtest.multiplyVec(a_meas);

            this.q = q_new;
            this.madgwick.setQuaternion(this.q);
        }

        // Update orientation
        this.madgwick.update(w_meas.x, w_meas.y, w_meas.z, a_meas.x, a_meas.y, a_meas.z, dt);
        this.q = { ...this.madgwick.q };

        // World-frame acceleration
        const R = QuatMath.toRotationMatrix(this.q); // body->world
        const acc_world = R.multiplyVec(a_meas);
        const g_vec = { x: 0, y: 0, z: this.GRAVITY };
        const acc_net = Vec3Math.sub(acc_world, g_vec); // linear accel in world

        // Kalman integration
        if (!isStat) {
            this.kX.predict(acc_net.x, dt);
            this.kY.predict(acc_net.y, dt);
            this.kZ.predict(acc_net.z, dt);
        } else {
            // Predict + ZUPT + bias update
            this.kX.predict(acc_net.x, dt); this.kX.updateZUPT(acc_net.x);
            this.kY.predict(acc_net.y, dt); this.kY.updateZUPT(acc_net.y);
            this.kZ.predict(acc_net.z, dt); this.kZ.updateZUPT(acc_net.z);
        }

        this.p = { x: this.kX.getPosition(), y: this.kY.getPosition(), z: this.kZ.getPosition() };
        this.v = { x: this.kX.getVelocity(), y: this.kY.getVelocity(), z: this.kZ.getVelocity() };
        const relP = Vec3Math.sub(this.p, this.baselineP);

        // Debug (throttled)
        if (Math.random() < 0.02) {
            const magA = Math.sqrt(a_meas.x ** 2 + a_meas.y ** 2 + a_meas.z ** 2).toFixed(2);
            const magW = (metrics?.meanW ?? 0).toFixed ? metrics.meanW.toFixed(3) : '';
            const magV = Math.sqrt(this.v.x ** 2 + this.v.y ** 2 + this.v.z ** 2).toFixed(3);
            const accLin = Math.sqrt(acc_net.x ** 2 + acc_net.y ** 2 + acc_net.z ** 2).toFixed(3);
            console.log(`[Hybrid] Stat:${isStat} |A|:${magA} meanW:${magW} |V|:${magV} |Alin|:${accLin} Pz:${this.p.z.toFixed(3)}`);
        }

        this.rawDataBuffer.push({ timestamp: t, acc_net, q: { ...this.q }, p_raw: { ...this.p }, v_raw: { ...this.v } });

        // Visual correction: Z-up (physics) -> Y-up (UI)
        const fix = { w: 0.70710678, x: -0.70710678, y: 0, z: 0 };
        const q_visual = QuatMath.normalize(QuatMath.multiply(fix, this.q));

        const point: TrajectoryPoint = {
            timestamp: t,
            position: { ...this.p },
            rotation: q_visual,
            relativePosition: relP,
        };

        // Always keep lastPoint even if realtime disabled
        this.lastPoint = point;

        // If record-only, don't move UI path in real time
        if (!this.realtimeEnabled) {
            return { timestamp: t, position: Vec3Math.zero(), rotation: q_visual, relativePosition: Vec3Math.zero() };
        }

        this.path.push(point);
        return point;
    }

    private getRotationFromGravity(ax: number, ay: number, az: number): Quaternion {
        const norm = Math.sqrt(ax * ax + ay * ay + az * az);
        if (norm === 0) return QuatMath.identity();

        const u = { x: ax / norm, y: ay / norm, z: az / norm };
        const v = { x: 0, y: 0, z: 1 }; // target world Z

        const dot = u.x * v.x + u.y * v.y + u.z * v.z;
        if (dot > 0.999) return QuatMath.identity();
        if (dot < -0.999) return { w: 0, x: 1, y: 0, z: 0 };

        const w = 1 + dot;
        const x = u.y * v.z - u.z * v.y;
        const y = u.z * v.x - u.x * v.z;
        const z = u.x * v.y - u.y * v.x;

        return QuatMath.normalize({ w, x, y, z });
    }

    private updateBuffers(a: Vec3, w: Vec3) {
        const a_mag = Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
        const w_mag = Math.sqrt(w.x * w.x + w.y * w.y + w.z * w.z);

        this.accelBuffer.push(a_mag);
        this.gyroBuffer.push(w_mag);

        if (this.accelBuffer.length > this.bufferSize) this.accelBuffer.shift();
        if (this.gyroBuffer.length > this.bufferSize) this.gyroBuffer.shift();
    }

    private checkStationaryCandidate(): { isCandidate: boolean; metrics: any } {
        if (this.accelBuffer.length < this.bufferSize) return { isCandidate: false, metrics: {} };

        const mean = (arr: number[]) => arr.reduce((s, x) => s + x, 0) / arr.length;
        const variance = (arr: number[], m: number) => arr.reduce((s, x) => s + (x - m) * (x - m), 0) / arr.length;

        const meanA = mean(this.accelBuffer);
        const meanW = mean(this.gyroBuffer);

        const varA = variance(this.accelBuffer, meanA);
        const varW = variance(this.gyroBuffer, meanW);

        const stdA = Math.sqrt(varA);
        const stdW = Math.sqrt(varW);

        // Thresholds (starting point)
        const isAccelStable = Math.abs(meanA - this.GRAVITY) < 0.5 && stdA < 0.15;
        const isGyroStable = meanW < 0.15 && stdW < 0.05;

        return {
            isCandidate: isAccelStable && isGyroStable,
            metrics: { meanA, stdA, meanW, stdW, bufferSize: this.bufferSize, expectedHz: this.expectedHz },
        };
    }

    public isStationary(): boolean {
        return this.isStatState;
    }

    private getLastPoint(nowTs: number): TrajectoryPoint {
        if (this.lastPoint) return this.lastPoint;
        return {
            timestamp: nowTs,
            position: Vec3Math.zero(),
            rotation: QuatMath.identity(),
            relativePosition: Vec3Math.zero(),
        };
    }

    getPath() { return this.path; }
    getOrientation() { return this.q; }
    getVelocity() { return this.v; }
    getIsCalibrating() { return this.isCalibrating; }

    async calibrateAsync(d: number = 2000) {
        this.isCalibrating = true;
        this.calibrationBuffer = [];
        await new Promise(r => setTimeout(r, d));
        this.isCalibrating = false;

        this.isOrientationInitialized = false;
        this.resetKinematics();
    }

    applyPostProcessingCorrections() {
        return this.path;
    }
}

export const trajectoryService = new TrajectoryService();
